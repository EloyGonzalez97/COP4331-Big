<?php



		static $db;

			if(!isset($db))
			{
				$db = mysqli_connect("localhost", "webalex", "vr8aTp573L", "webalex_SwoleAF");
			}
			if($db === false)
			{
				return mysqli_connect_error();
			}


			$response = array();



			$sql = "CALL GetWorkouts()";

			$result = mysqli_query($db, $sql);

            while($r = mysqli_fetch_assoc($result)) {
			             $response[] = $r;
 		     }


            unset($db);

            echo json_encode($response)

 ?>
