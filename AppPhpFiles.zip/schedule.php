<?php


 if (isset($_POST['userid']))
 {
   // receiving the post params
   $id = $_POST['userid'];

   static $db;
     if(!isset($db))
     {
       $db = mysqli_connect("localhost", "webalex", "vr8aTp573L", "webalex_SwoleAF");
     }
     if($db === false)
     {
       return mysqli_connect_error();
     }

     $response = array("error" => FALSE);
     $response2 = array();
     $sql = "CALL GetWeeklySchedule('" . $id . "')";

     $result = mysqli_query($db, $sql);


    if($result->num_rows > 0)
     {
       $response["error"] = FALSE;

       for($i = 0; $i < $result->num_rows; $i++)

       while($row = $result->fetch_assoc())
       {
         $response["weekday"] = $row["Weekday"];
         $response["starttime"] = $row["StartTime"];
         $response["rid"] = $row["Routines.RoutineID"];
         $response["rname"] = $row["RoutineName"];
         $response["rdifficulty"] = $row["RoutineDifficulty"];
         $response["wid"] = $row["Workouts.WorkoutID"];
         $response["wname"] = $row["WorkoutName"];
        // $response["wmg"] = $row["MuscleGroupLookup.MuscleGroupName"];
         $response["reps"] = $row["Reps"];
         $response["weight"] = $row["Weight"];
         $response["sets"] = $row["Sets"];
         $response["wdescription"] = $row["WorkoutDescription"];
         //$response2[] = json_encode($response);
         $response2[] = $response;
         //echo json_encode($response);
       }

      echo json_encode($response2);

     }

     else
     {
        $response["error"] = TRUE;
        $response["error_msg"] = "Failure.";
        echo json_encode($response);
     }
 }
?>
