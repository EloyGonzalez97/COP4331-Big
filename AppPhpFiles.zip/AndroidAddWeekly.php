<?php


   if (isset($_POST['userid']) isset($_POST['routineid']) isset($_POST['weekday']) && isset($_POST['time']))
   {



       // receiving the post params
       $userid = $_POST['userid'];
       $routineid = $_POST['routineid'];
       $weekday = $_POST['weekday'];
       $time = $_POST['time'];


       static $db;
           if(!isset($db))
           {
               $db = mysqli_connect("localhost", "webalex", "vr8aTp573L", "webalex_SwoleAF");
           }
           if($db === false)
           {
               return mysqli_connect_error();
           }



           $sql = "CALL addWeeklySchedule('" . $userid . "','" . $routineid . "','" . $weekday . "','" . $time . "')";

           if(mysqli_query($db, $sql)) {
               echo json_encode(FALSE);
           }
           else
           {
               echo json_encode(TRUE);
           }

           unset($db);
   }
   else{
       echo json_encode(TRUE);
   }
?>
