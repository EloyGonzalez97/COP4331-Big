 <?php  
 $db_name = "webalex_SwoleAF";  
 $mysql_user = "webalex";  
 $mysql_pass = "rvr8aTp573L";  
 $server_name = "localhost";  
 $con = mysqli_connect($server_name,$mysql_user,$mysql_pass,$db_name);  
 ?>  