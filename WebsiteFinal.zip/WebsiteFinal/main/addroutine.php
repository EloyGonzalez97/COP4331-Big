<?phpa
	
class AddRoutine {
	public function __construct() {

	}

	public function connect() {
			static $db;

			if(!isset($db)) {
				$db = mysqli_connect("localhost", "webalex", "vr8aTp573L", "webalex_SwoleAF");
			}

			if($db === false) {
				return mysqli_connect_error();
			}

			return $db;
	}

	public function addRoutine($name, $description, $difficulty, $accessID) { 
		$db = $this->connect();
		$sql = "CALL AddRoutine('" . $name . "','" . $description . "','" . $difficulty . "','" . $accessID . "')";
		$result = mysqli_query($db, $sql);
		if($result->num_rows > 0) {
			$row = mysqli_fetch_assoc($result);
			return $row["LAST_INSERT_ID()"];
		}
		unset($db);
	}
}
	

?>